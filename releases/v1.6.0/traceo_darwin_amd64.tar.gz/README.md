# Traceo CLI

`traceo` 是 Traceo 在线服务的 CLI 客户端与 skill 入口。

当前仓库包含：

- `traceo` CLI 命令入口
- 用户级 bearer 认证、profile/config、workspace 选择、token refresh
- Traceo Server 的 HTTP client
- `skill/`
- 基于 GitHub Release 的平台二进制分发与安装脚本

## 安装

推荐直接安装最新发布的二进制：

```bash
curl -fsSL https://raw.githubusercontent.com/caik13/traceo-cli/main/scripts/install.sh | sh
```

安装完成后首次登录：

```bash
traceo auth login --host http://localhost:8080 --no-browser
```

查看帮助：

```bash
traceo --help
traceo help skill
traceo help skill install
traceo skill help
```

## 开发验证

常用本地验证命令：

```bash
go test ./...
go build -ldflags "-X traceo/internal/cli.BuildVersion=$(cat VERSION)" -o ./dist/traceo ./cmd/traceo
```

## 常用命令

```bash
traceo auth status --json
traceo workspace list --json
traceo workspace use ws_team_1
traceo config skill
traceo skill install --tool codex
traceo skill install --path ~/.local/share/traceo-skill
traceo search "vite timeout"
traceo store --input ./bug.json
```

CLI 默认把 profile 元数据写入 `~/.config/traceo/config.json`，把 token 写入系统 credential store；如果系统 keychain 不可用，则回退到 `~/.config/traceo/credentials.json`。项目级 workspace 绑定写入 `.traceo/config.json`。

认证流程：

- `traceo auth login` 先请求 `/api/v1/version`，确认服务端 API 版本和 CLI 兼容窗
- 然后走 `/api/v1/cli/auth/device-requests` + `/api/v1/cli/auth/device-requests/poll` 的 device flow
- 浏览器会打开服务端返回的 `/app/cli/auth` 授权页；如果直接访问根路径，server 会先跳转到 `/app/`
- 登录成功后保存 refresh token、access token 和当前 workspace
- 业务请求统一走 `Authorization: Bearer <accessToken>`，bearer 失效时自动调用 `/api/v1/cli/auth/tokens/refresh`

`traceo store` 支持两种输入方式：

- `traceo store --input ./bug.json`
- `cat bug.json | traceo store`

## Skill 安装

Traceo skill 不会自动写入 Codex 目录，需要显式执行：

```bash
traceo skill install --tool codex
```

或者使用引导式安装：

```bash
traceo config skill
```

Codex 默认安装目录是 `$CODEX_HOME/skills/traceo`；如果 `CODEX_HOME` 未设置，则回退到 `~/.codex/skills/traceo`。

## 发布模型

仓库采用 `release-please + VERSION + GoReleaser + scripts/install.sh` 的二进制发布模型：

- `VERSION` 是仓库内唯一版本真源
- `release-please` 在 `main` 上维护 release PR，并更新 `VERSION` 与 `CHANGELOG.md`
- `release.yml` 在 `vX.Y.Z` tag 上运行 GoReleaser，生成各平台归档与 `checksums.txt`
- `scripts/install.sh` 从 GitHub Release 下载并校验对应平台的二进制

`traceo-cli` 只保留在线 CLI 所需的命令解析、配置/认证、HTTP client 与 skill 安装逻辑，不再内置本地业务层或 embedding/迁移实现。

## 文档入口

1. [docs/architecture.md](/Users/qianchen/Documents/project/traceo/traceo-cli/docs/architecture.md)
2. [docs/usage-guide.md](/Users/qianchen/Documents/project/traceo/traceo-cli/docs/usage-guide.md)
3. [docs/software-design.md](/Users/qianchen/Documents/project/traceo/traceo-cli/docs/software-design.md)
4. [docs/release-playbook.md](/Users/qianchen/Documents/project/traceo/traceo-cli/docs/release-playbook.md)
